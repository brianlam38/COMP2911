nicest way is to use an adjacency list format for graphics in Java.

Each array index has a list

Maybe a:
	GRAPH CLASS
	- See graph operations slide
	NODE CLASS
	
	EDGES
	- What are the weights of each edge
	- What nodes are connected to the edge

