import java.util.*;

public class InternetAccount extends BankAccount {
	
	public void payment(int amount) {
		
	}
}
